package com.learnopengles.android.util;

public class LoggerConfig {
	public static final boolean ON = true;
}
